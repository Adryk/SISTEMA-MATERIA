from django.shortcuts import render,redirect
from .models import Alumno,Materia
from .forms import FormularioAlumno,FormularioMateria

from django.contrib import messages


# Create your views here.
def listar(request):
	materia=Materia.objects.all()
	alumnos=Alumno.objects.all()
	context={
		'materia':materia,
		'alumnos':alumnos,
	}
	return render(request,"listarma.html",context)
def crear(request):
	f=FormularioMateria(request.POST or None)
	context={
		'f':f,
	}
	if f.is_valid():
		f_data=f.cleaned_data
		cl=Materia()
		cl.id_materia=f_data.get("id_materia")	
		cl.nombre=f_data.get("nombre")
		cl.cupo=f_data.get("cupo")
		cl.numero_matriculados=f_data.get("numero_matriculados")
		
		if (cl.save() !=True):
			materia=Materia.objects.all()
			context={
			'materia':materia,
			}
			return redirect(listar)

	return render(request,"crearma.html",context)
def crearalumno(request):
	f=FormularioAlumno(request.POST or None)
	context={
		'f':f,

	}
	if f.is_valid():
		f_data=f.cleaned_data
		cl=Alumno()
		cl.id_alumno=f_data.get("id_alumno")	
		cl.Nombre=f_data.get("Nombre")
		cl.Apellido=f_data.get("Apellido")
		cl.Cedula=f_data.get("Cedula")
		
		
		
		if (cl.save() !=True):
			alumnos=Alumno.objects.all()
			context={
			'alumnos':alumnos,
			}
			return redirect(listar)
	return render (request,"crearal.html",context)

def eliminarMateria(request):
	ma=Materia.objects.get(nombre=request.GET["nombre"])	
	ma.delete()
	return redirect(listar)
def eliminarEstudiante(request):
	a=Alumno.objects.get(Cedula=request.GET["cedula"])	
	a.delete()
	return redirect(listar)