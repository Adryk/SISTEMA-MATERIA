from django.conf.urls import  url
from django.contrib import admin

urlpatterns = [

    url(r'^$', 'matricula.views.listar'),
    url(r'^crear/$', 'matricula.views.crear'),
     url(r'^crearalumno/$', 'matricula.views.crearalumno'),
     url(r'^eliminarMateria/$', 'matricula.views.eliminarMateria'),
     url(r'^eliminarEstudiante/$', 'matricula.views.eliminarEstudiante'),
    
]