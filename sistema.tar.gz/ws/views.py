from matricula.models import Materia,Alumno

from rest_framework import viewsets
from .serializable import MateriaSerializable,AlumnoSerializable


class MateriaViewSet(viewsets.ModelViewSet):
	#llamo al objeto serializable
	serializer_class=MateriaSerializable
	#defino la consulta de sdatos que se enviaran enla ws
	queryset=Materia.objects.filter(numero_matriculados__lte= 29)
	#queryset=Materia.objects.all()


class AlumnoViewSet(viewsets.ModelViewSet):
	#llamo al objeto serializable
	serializer_class=AlumnoSerializable
	#defino la consulta de sdatos que se enviaran enla ws
	queryset=Alumno.objects.all()
	#queryset=Materia.objects.all()