from __future__ import unicode_literals

from django.db import models
class Materia(models.Model):
	id_materia=models.CharField(max_length=30,unique=True)
	nombre=models.CharField(max_length=30,unique=True)
	cupo=models.IntegerField()
	numero_matriculados=models.IntegerField()

	def __str__(self):
		return self.nombre

class Alumno(models.Model):
	id_alumno=models.CharField(max_length=30,unique=True)
	Nombre=models.CharField(max_length=30)
	Apellido=models.CharField(max_length=30)
	Cedula=models.CharField(max_length=10,unique=True)
	id_materia=models.CharField(max_length=30)
	def __str__(self):
		return self.Nombre

