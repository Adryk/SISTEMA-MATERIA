#transformarlos objetos y dar propiedad para quesepuedan reprwesentar en otros formatos
from matricula.models import Materia,Alumno

from rest_framework import serializers 

class MateriaSerializable(serializers.ModelSerializer):
	class Meta:
		model=Materia
		fields=('id_materia','nombre','cupo','numero_matriculados')
class AlumnoSerializable(serializers.ModelSerializer):
	class Meta:
		model=Alumno
		fields=('id_alumno','Nombre','Apellido','Cedula')


