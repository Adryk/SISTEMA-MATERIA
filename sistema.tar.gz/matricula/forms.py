from django import forms
from .models import Materia

from .models import Alumno
class FormularioMateria(forms.ModelForm):	
	class Meta:
		model=Materia
		fields=["id_materia","nombre","cupo","numero_matriculados"]
		
class FormularioAlumno(forms.ModelForm):
	class Meta:
		model=Alumno
		fields=["id_alumno","Nombre","Apellido","Cedula","id_materia"]
	